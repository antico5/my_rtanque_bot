class EnemyInfo
  attr_accessor :name, :headings, :distances, :last_updated

  def initialize reflection
    @name = reflection.name
    @headings = []
    @distances = []
    @last_updated = 0
  end

  def process reflection
    headings << reflection.heading
    distances << reflection.distance
  end
end
